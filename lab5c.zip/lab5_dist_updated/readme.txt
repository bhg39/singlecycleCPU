Brandon Guo
bhg39

Using iram2E, I first confirmed that the processor actually halted on the proper instruction.
Next, I checked that the PC continued counting on the negative edge of EN_L tracking EN_L and EN_L previous.
Then, I checked that the PC continued at the next instruction and didn't skip instructions.
Finally, I checked in the waveform that the registers weren't being written to.

Because all of tests are satisfied, I have verified that HALT works properly.

  